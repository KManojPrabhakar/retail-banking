import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayeeComponent } from './payee.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HelperService } from 'src/app/service/helper.service';
import { Router } from '@angular/router';

describe('PayeeComponent', () => {
  let component: PayeeComponent;
  let fixture: ComponentFixture<PayeeComponent>;
  let helperService: HelperService;
  let router: Router;
  const selectedBeneficiaryData = {
    id: 0,
    name: "test",
    accountNo: "1234567890",
    emailId: "test@gmail.com"
  }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PayeeComponent],
      imports: [RouterTestingModule]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get beneficiaryAccounts', () => {
    helperService = new HelperService(router);
    expect(helperService.getBeneficiaryDetails()).toEqual(null);
  });


  it('should get transaction Details', () => {
    helperService = new HelperService(router);
    expect(helperService.getTranscationDetails()).toEqual(null);
  });

  it('transferAccountForm  should be invalid', () => {
    component.transferAccountForm.controls['amount'].setValue('');
    component.transferAccountForm.controls['selectedBeneficiary'].setValue('');

    expect(component.transferAccountForm.valid).toBeFalsy();


  })

  it('transferAccountForm  should be valid', () => {
    component.transferAccountForm.controls['amount'].setValue(1234);
    component.transferAccountForm.controls['selectedBeneficiary'].setValue(selectedBeneficiaryData);
    expect(component.transferAccountForm.valid).toBeTruthy();

  });
});
