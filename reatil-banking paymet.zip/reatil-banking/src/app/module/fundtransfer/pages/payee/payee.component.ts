import { Component, OnInit } from '@angular/core';
import { HelperService } from 'src/app/service/helper.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { Router } from '@angular/router';


@Component({
  selector: 'app-payee',
  templateUrl: './payee.component.html',
  styleUrls: ['./payee.component.css'],
  providers: [MessageService]

})
export class PayeeComponent implements OnInit {
  transferAccountForm: FormGroup;
  userAccount: any;
  beneficiaryAccounts: any;
  selectedBeneficiary: any;
  transactionDetails: any;
  constructor(private helperService: HelperService, private messageService: MessageService, private router:Router) { }

  ngOnInit(): void {
    this.beneficiaryAccounts = [];
    this.transactionDetails = [];
    this.beneficiaryAccounts = this.helperService.getBeneficiaryDetails();
    console.log('beneficiaryAccounts', this.beneficiaryAccounts);
    if(this.beneficiaryAccounts && this.beneficiaryAccounts.length) {
      this.beneficiaryAccounts = JSON.parse(this.beneficiaryAccounts);
    } else {
      this.beneficiaryAccounts = [];
    }

    this.transactionDetails = this.helperService.getTranscationDetails();
    console.log('transaction Details', this.transactionDetails);
    if(this.transactionDetails && this.transactionDetails.length) {
      this.transactionDetails = JSON.parse(this.transactionDetails);
    } else {
      this.transactionDetails = [];
    }

    this.transferAccountForm = new FormGroup({
      amount: new FormControl('', [Validators.required]),
      selectedBeneficiary: new FormControl('', [Validators.required])

    });
    console.log('beneficiaryAccounts after', this.beneficiaryAccounts);

  }

  handlePayeeButton() {
    console.log('handlePayeeButton', this.transferAccountForm.value);
    const transactionData = {
      date: new Date(),
      narration: `Transfer amount to ${this.transferAccountForm.value.selectedBeneficiary.name}`,
      cheque: this.transferAccountForm.value.selectedBeneficiary.accountNo,
      valueDate: new Date(),
      withdraw: this.transferAccountForm.value.amount,
      deposit: ''
        }
        this.transactionDetails.push(transactionData);
    this.helperService.storeTranscationDetails(this.transactionDetails);
    this.messageService.add({severity:'success', summary:'Payment', detail:'Amount Transfered Successfully'});
    const url = 'dashboard/view';
    this.router.navigate([url]);


  }

  navigateToBeneficiaryAccount() {
    console.log('navigateToBeneficiaryAccount');
    const url = 'fundtransfer/beneficiary';
    this.router.navigate([url]);
  }

}
