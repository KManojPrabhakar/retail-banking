import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FundtransferRoutingModule } from './fundtransfer-routing.module';
import { FundComponent } from './pages/fund/fund.component';
import { FundCardComponent } from './components/fund-card/fund-card.component';
import { PrimeModule } from 'src/app/shared/primeng-module';
import { AddBeneficiaryComponent } from './pages/add-beneficiary/add-beneficiary.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PayeeComponent } from './pages/payee/payee.component';
import { TransferComponent } from './pages/transfer/transfer.component';


@NgModule({
  declarations: [FundComponent, FundCardComponent, AddBeneficiaryComponent, PayeeComponent, TransferComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    PrimeModule,
    FundtransferRoutingModule
  ]
})
export class FundtransferModule { }
