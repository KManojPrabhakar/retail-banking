import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class HelperService {


  constructor(private router: Router) { }

  navigateToHistoryBack() {
    window.history.back();
  }

  addBeneficiaryDetails(beneficiaryData) {
    sessionStorage.setItem('beneficiaryData', JSON.stringify(beneficiaryData));

  }

  getBeneficiaryDetails() {
    return sessionStorage.getItem('beneficiaryData');
  }

  storeTranscationDetails(transactionData) {
    sessionStorage.setItem('transactionData',JSON.stringify(transactionData));
  
    }
    getTranscationDetails() {
    return sessionStorage.getItem('transactionData');
    }
}
