import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HelperService } from 'src/app/service/helper.service';
import { MessageService } from 'primeng/api';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-beneficiary',
  templateUrl: './add-beneficiary.component.html',
  styleUrls: ['./add-beneficiary.component.css'],
  providers: [MessageService]

})
export class AddBeneficiaryComponent implements OnInit {
  beneficiaryForm: FormGroup;
  beneficiaryData: any;
  constructor(private helperService: HelperService, private messageService: MessageService, private router: Router) { }

  ngOnInit(): void {
    this.beneficiaryData = [];
    this.beneficiaryData = this.helperService.getBeneficiaryDetails();
    if(this.beneficiaryData && this.beneficiaryData.length) {
      this.beneficiaryData = JSON.parse(this.beneficiaryData);
    } else {
      this.beneficiaryData = [];
    }
    this.beneficiaryForm = new FormGroup({
      accountNo: new FormControl('', [Validators.required]),
      reEnterAccountNo: new FormControl('', [Validators.required]),
      nickName: new FormControl('', [Validators.required]),
      emailId: new FormControl('', [Validators.required, Validators.email]),


    });
  }

  navigateToHistoryBack() {
    console.log('navigateToHistoryBack');
    this.helperService.navigateToHistoryBack();
  }

  handleAddButton() {
    console.log('handleAddButton', this.beneficiaryForm.value);
    const length = this.beneficiaryData.length;
    const beneficiaryData = {
      label: `${this.beneficiaryForm.value.nickName} (${this.beneficiaryForm.value.accountNo})`,
      value: {
        id: length,
        name: this.beneficiaryForm.value.nickName,
        accountNo: this.beneficiaryForm.value.accountNo,
        emailId: this.beneficiaryForm.value.emailId
      }
    }
    this.beneficiaryData.push(beneficiaryData);
    console.log('beneficiaryData', beneficiaryData);
  
    this.helperService.addBeneficiaryDetails(this.beneficiaryData);
    this.messageService.add({severity:'success', summary:'Beneficary', detail:'Add Beneficiary Details Successfully'});
    this.navigateToPaymentPage();
  }

  navigateToPaymentPage() {
    console.log('navigateToAddBeneficiaryAccount');
    const url = 'fundtransfer/payee';
    // this.router.navigate([url]);
    this.router.navigateByUrl(url);
  }
  numberOnly(event): boolean {
    return this.helperService.numberOnly(event);
  }

}
