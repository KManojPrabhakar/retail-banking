import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayeeComponent } from './payee.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HelperService } from 'src/app/service/helper.service';
import { Router } from '@angular/router';

describe('PayeeComponent', () => {
  let component: PayeeComponent;
  let fixture: ComponentFixture<PayeeComponent>;
  let helperService: HelperService;
  const selectedBeneficiaryData = {
    id: 0,
    name: "test",
    accountNo: "1234567890",
    emailId: "test@gmail.com"
  };
  const transactionData = {
    date: new Date(),
    narration: `Transfer amount to manoj`,
    cheque: 1234567890,
    valueDate: new Date(),
    withdraw: 0,
    deposit: ''
  }
  const routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PayeeComponent],
      imports: [RouterTestingModule]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('store beneficiary accounts', () => {
  //   helperService = new HelperService();
  //   expect(helperService.addBeneficiaryDetails([selectedBeneficiaryData])).toEqual(null);
  // });

  it('should get beneficiaryAccounts', () => {
    helperService = new HelperService();
    expect(helperService.getBeneficiaryDetails()).toEqual(null);
  });


  

  it('transferAccountForm  should be invalid', () => {
    component.transferAccountForm.controls['amount'].setValue('');
    component.transferAccountForm.controls['selectedBeneficiary'].setValue('');

    expect(component.transferAccountForm.valid).toBeFalsy();


  })

  it('transferAccountForm  should be valid', () => {
    component.transferAccountForm.controls['amount'].setValue(1234);
    component.transferAccountForm.controls['selectedBeneficiary'].setValue(selectedBeneficiaryData);
    expect(component.transferAccountForm.valid).toBeTruthy();

  });

  // it('# should call number only method payment component', () => {
  //   const hostElement = fixture.nativeElement;
  //   // const nameInput: HTMLInputElement = hostElement.querySelector('input');
  //   const event = new KeyboardEvent("keypress",{
  //     "key": "Enter"
  // });
  // // nameInput.dispatchEvent(event);
  // fixture.detectChanges();

  //   expect(component.numberOnly(event)).toHaveBeenCalled();
  // });

  it('should tell ROUTER to navigateToPaymentPage when payee  button clicked', () => {
    component.navigateToBeneficiaryAccount();
    // args passed to router.navigateByUrl() spy
    const spy = routerSpy.navigateByUrl as jasmine.Spy;
    const navArgs = spy.calls.first().args[0];

    expect(navArgs).toBe('fundtransfer/beneficiary',
      'should nav to beneficiary page');
  });
});
