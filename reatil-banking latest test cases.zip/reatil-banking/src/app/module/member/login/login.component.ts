import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HelperService } from 'src/app/service/helper.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  constructor(private helperService: HelperService) { }

  ngOnInit() {
    this.loginForm = new FormGroup({
      email: new FormControl('', [Validators.required,  Validators.email]),
      number: new FormControl('', [Validators.required]),
    });
  }
  numberOnly(event): boolean {
    return this.helperService.numberOnly(event);
  }

  handleLoginButton() {
    console.log('handleLoginButton', this.loginForm.value);
  }

}
