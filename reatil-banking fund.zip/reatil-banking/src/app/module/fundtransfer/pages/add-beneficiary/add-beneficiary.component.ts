import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HelperService } from 'src/app/service/helper.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-add-beneficiary',
  templateUrl: './add-beneficiary.component.html',
  styleUrls: ['./add-beneficiary.component.css'],
  providers: [MessageService]

})
export class AddBeneficiaryComponent implements OnInit {
  beneficiaryForm: FormGroup;

  constructor(private helperService: HelperService, private messageService: MessageService) { }

  ngOnInit(): void {
    this.beneficiaryForm = new FormGroup({
      accountNo: new FormControl('', [Validators.required]),
      reEnterAccountNo: new FormControl('', [Validators.required]),
      nickName: new FormControl('', [Validators.required]),
      emailId: new FormControl('', [Validators.required]),


    });
  }

  navigateToHistoryBack() {
    console.log('navigateToHistoryBack');
    this.helperService.navigateToHistoryBack();
  }

  handleAddButton() {
    console.log('handleAddButton', this.beneficiaryForm.value);
    const beneficiaryData = {
      accountNo: this.beneficiaryForm.value.accountNo,
      emailId: this.beneficiaryForm.value.emailId
    }
    console.log('beneficiaryData', beneficiaryData);
  
    this.helperService.addBeneficiaryDetails(beneficiaryData)
    this.messageService.add({severity:'success', summary:'Beneficary', detail:'Add Beneficiary Details Successfully'});

  }

}
