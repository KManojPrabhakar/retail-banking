import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FundtransferRoutingModule } from './fundtransfer-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FundtransferRoutingModule
  ]
})
export class FundtransferModule { }
