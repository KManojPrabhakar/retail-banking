import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FundCardComponent } from './fund-card.component';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';

describe('FundCardComponent', () => {
  let component: FundCardComponent;
  let fixture: ComponentFixture<FundCardComponent>;
  let router: Router;
  const routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FundCardComponent],
      imports: [RouterTestingModule],
      providers: [
        { provide: Router, useValue: routerSpy }
      ]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FundCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to add Beneficiary account ', () => {
    expect(component).toBeTruthy();
  });


  it('should tell ROUTER to navigateToPaymentPage when go button clicked', () => {
    component.navigateToPaymentPage();
    // args passed to router.navigateByUrl() spy
    const spy = routerSpy.navigateByUrl as jasmine.Spy;
    const navArgs = spy.calls.first().args[0];

    expect(navArgs).toBe('fundtransfer/beneficiary',
      'should nav to payment page');
  });

  it('should tell ROUTER to navigateToAddBeneficiaryAccount when go button clicked', () => {

    component.navigateToAddBeneficiaryAccount();
      // args passed to router.navigateByUrl() spy
      const spy = routerSpy.navigateByUrl as jasmine.Spy;
      const navArgs = spy.calls.first().args[0];
    
      console.log('navArgs',navArgs,'spy.calls.first()', spy.calls.first());
      expect(navArgs).toBe('fundtransfer/beneficiary',
        'should nav to beneficiary page');
    });
});
