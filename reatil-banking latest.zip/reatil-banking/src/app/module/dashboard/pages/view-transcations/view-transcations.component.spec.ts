import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewTranscationsComponent } from './view-transcations.component';

describe('ViewTranscationsComponent', () => {
  let component: ViewTranscationsComponent;
  let fixture: ComponentFixture<ViewTranscationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewTranscationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewTranscationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
