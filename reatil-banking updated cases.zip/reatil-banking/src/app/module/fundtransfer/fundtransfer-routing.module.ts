import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FundComponent } from './pages/fund/fund.component';
import { AddBeneficiaryComponent } from './pages/add-beneficiary/add-beneficiary.component';
import { PayeeComponent } from './pages/payee/payee.component';
import { TransferComponent } from './pages/transfer/transfer.component';


const routes: Routes = [
  {
    path: '', 
    component: FundComponent
  },
  {
    path: 'beneficiary',
    component: AddBeneficiaryComponent
  }, 
  {
    path: 'payee',
    component: PayeeComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FundtransferRoutingModule { }
