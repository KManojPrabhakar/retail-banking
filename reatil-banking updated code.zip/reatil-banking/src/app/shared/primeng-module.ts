import { NgModule } from '@angular/core';
import { TableModule } from 'primeng/table';
import {CardModule} from 'primeng/card';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import {CarouselModule} from 'primeng/carousel';
import {RadioButtonModule} from 'primeng/radiobutton';
import {DialogModule} from 'primeng/dialog';
import {ButtonModule} from 'primeng/button';
import {RatingModule} from 'primeng/rating';
import {SliderModule} from 'primeng/slider';
import {TabViewModule} from 'primeng/tabview';
import {AccordionModule} from 'primeng/accordion';
import {LightboxModule} from 'primeng/lightbox';
import {ToastModule} from 'primeng/toast';
import {MultiSelectModule} from 'primeng/multiselect';
import {InputTextModule} from 'primeng/inputtext';


const Modules = [
    TableModule,
    CardModule,
    CalendarModule,
    DropdownModule,
    RadioButtonModule,
    ButtonModule,
    CarouselModule,
    DialogModule,
    RatingModule,
    SliderModule,
    TabViewModule,
    AccordionModule,
    LightboxModule,
    ToastModule,
    MultiSelectModule,
    InputTextModule

]
@NgModule({
  declarations: [],
  imports: [...Modules],
  providers: [],
  exports: [ ...Modules ]
})
export class PrimeModule { }
