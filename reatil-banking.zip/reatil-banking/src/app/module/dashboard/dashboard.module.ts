import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { AccountDetailsComponent } from './components/account-details/account-details.component';
import { PrimeModule } from 'src/app/shared/primeng-module';
import { ViewTranscationsComponent } from './components/view-transcations/view-transcations.component';


@NgModule({
  declarations: [DashboardComponent, AccountDetailsComponent, ViewTranscationsComponent],
  imports: [
    CommonModule,
    PrimeModule,
    DashboardRoutingModule
  ]
})
export class DashboardModule { }
