import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewTranscationsComponent } from './view-transcations.component';
import { RouterTestingModule } from '@angular/router/testing';

describe('ViewTranscationsComponent', () => {
  let component: ViewTranscationsComponent;
  let fixture: ComponentFixture<ViewTranscationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewTranscationsComponent ],
      imports: [RouterTestingModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewTranscationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
