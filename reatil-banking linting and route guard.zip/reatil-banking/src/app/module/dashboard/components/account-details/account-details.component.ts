import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HelperService } from 'src/app/service/helper.service';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {
  currentBalance: number = 0;
  constructor(private router: Router, private helperService: HelperService) { }

  ngOnInit(): void {
    this.currentBalance = this.helperService.getCurrentBalance();
  }

  handleClick() {
    console.log('handleClick');
    const url = 'dashboard/view';
    this.router.navigate([url]);
  }


}
