import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountDetailsComponent } from './account-details.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HelperService } from 'src/app/service/helper.service';
import { Router } from '@angular/router';

describe('AccountDetailsComponent', () => {
  let component: AccountDetailsComponent;
  let fixture: ComponentFixture<AccountDetailsComponent>;
  let helperService: HelperService;
  let navigateRouter = {
    navigate: jasmine.createSpy('dashboard/view')
  }
  const routerSpy = jasmine.createSpyObj('Router', ['navigate']);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AccountDetailsComponent],
      imports: [RouterTestingModule],
      providers: [{ provide: Router, useValue: navigateRouter }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('#getCurrentBalance should return real value from the helper service', () => {
    helperService = new HelperService();
    expect(helperService.getCurrentBalance()).toBe(10000);
  });

  it('handle click method should navigate to dashboard view', async(() => {
    const spy = navigateRouter.navigate as jasmine.Spy;
    console.log('spy data',spy, spy.calls, spy.calls.argsFor(0));
    expect('/dashboard/view').toBe('/dashboard/view',
      'should nav to dashboard view');
  }));

  it('should have Name Text <h3>', () => {
    const h3: HTMLElement = fixture.nativeElement.querySelector('h3');
    expect(h3.textContent).toContain('Name');
  });
});
