import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayeeComponent } from './payee.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HelperService } from 'src/app/service/helper.service';
import { Router } from '@angular/router';

describe('PayeeComponent', () => {
  let component: PayeeComponent;
  let fixture: ComponentFixture<PayeeComponent>;
  let helperService: HelperService;
  const selectedBeneficiaryData = {
    id: 0,
    name: "test",
    accountNo: "1234567890",
    emailId: "test@gmail.com"
  };
  const transactionData = {
    date: new Date(),
    narration: `Transfer amount to manoj`,
    cheque: 1234567890,
    valueDate: new Date(),
    withdraw: 0,
    deposit: ''
  }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PayeeComponent],
      imports: [RouterTestingModule]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('store beneficiary accounts', () => {
  //   helperService = new HelperService();
  //   expect(helperService.addBeneficiaryDetails([selectedBeneficiaryData])).toEqual(null);
  // });

  it('should get beneficiaryAccounts', () => {
    helperService = new HelperService();
    expect(helperService.getBeneficiaryDetails()).toEqual(null);
  });


  

  it('transferAccountForm  should be invalid', () => {
    component.transferAccountForm.controls['amount'].setValue('');
    component.transferAccountForm.controls['selectedBeneficiary'].setValue('');

    expect(component.transferAccountForm.valid).toBeFalsy();


  })

  it('transferAccountForm  should be valid', () => {
    component.transferAccountForm.controls['amount'].setValue(1234);
    component.transferAccountForm.controls['selectedBeneficiary'].setValue(selectedBeneficiaryData);
    expect(component.transferAccountForm.valid).toBeTruthy();

  });

  it('should check the value should only allow numberOnly', async(() => {
    helperService = new HelperService();
    spyOn(component, 'numberOnly');
    fixture = TestBed.createComponent(PayeeComponent);
    fixture.detectChanges();
    let input = fixture.debugElement.nativeElement.querySelector('input');
    console.log('input', fixture)
    input.keypress();    
    fixture.whenStable().then(() => {
      expect(component.numberOnly).toHaveBeenCalled();
    });
  }));

  // it('helper service storeTranscationDetails', () => {
  //   helperService = new HelperService();
  //   expect(helperService.storeTranscationDetails([transactionData])).toEqual(null);
  // });

  // it('should get transaction Details', () => {
  //   helperService = new HelperService();
  //   expect(helperService.getTranscationDetails()).toEqual('manoj');
  // });

});
