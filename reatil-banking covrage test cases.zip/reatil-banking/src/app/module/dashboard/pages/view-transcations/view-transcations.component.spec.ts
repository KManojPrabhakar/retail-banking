import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewTranscationsComponent } from './view-transcations.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HelperService } from 'src/app/service/helper.service';
import { Router } from '@angular/router';

describe('ViewTranscationsComponent', () => {
  let component: ViewTranscationsComponent;
  let fixture: ComponentFixture<ViewTranscationsComponent>;
  let helperService: HelperService;
  const transactionData = {
    date: new Date(),
    narration: `Transfer amount to manoj`,
    cheque: 1234567890,
    valueDate: new Date(),
    withdraw: 100,
    deposit: ''
  }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ViewTranscationsComponent],
      imports: [RouterTestingModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewTranscationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('#view transaction page should get transaction Details', () => {
  //   helperService = new HelperService();
  //   expect(helperService.getTranscationDetails()).toEqual(null);
  // });

  

});
