import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-transcations',
  templateUrl: './view-transcations.component.html',
  styleUrls: ['./view-transcations.component.css']
})
export class ViewTranscationsComponent implements OnInit {
  cars: any;
  brands: any;
  colors: any;
  cols: any;
  details: any;
  constructor() { }

  ngOnInit(): void {

    this.cols = [
      { field: 'date', header: 'Date' },
      { field: 'narration', header: 'Narration' },
      { field: 'cheque', header: 'Cheque/Ref' },
      { field: 'valueDate', header: 'Value Date' },
      { field: 'withdraw', header: 'Withdrawl' },
      { field: 'deposit', header: 'Deposit' },


    ];
    this.details = [ 
      {
        date: new Date(),
        narration: 'Transfer amount',
        cheque: 12341,
        valueDate: new Date(),
        withdraw: 807,
        deposit: 123456
      },
      {
        date: new Date(),
        narration: 'Transfer amount 2',
        cheque: 8923535900,
        valueDate: new Date(),
        withdraw: 57890,
        deposit: ''
      },
      {
        date: new Date(),
        narration: 'Transfer amount 3',
        cheque: 467498289,
        valueDate: new Date(),
        withdraw: '',
        deposit: 12809909009
      }
    ];

    this.cars = [
      {
        vin: 124,
        year: 1926,
        brand: 'bmw',
        color: 'red'
      },
      {
        vin: 13,
        year: 193,
        brand: 'audi',
        color: 'black'
      }
    ];

    this.brands = [
      { label: 'All Brands', value: null },
      { label: 'Audi', value: 'Audi' },
      { label: 'BMW', value: 'BMW' },
      { label: 'Fiat', value: 'Fiat' },
      { label: 'Honda', value: 'Honda' },
      { label: 'Jaguar', value: 'Jaguar' },
      { label: 'Mercedes', value: 'Mercedes' },
      { label: 'Renault', value: 'Renault' },
      { label: 'VW', value: 'VW' },
      { label: 'Volvo', value: 'Volvo' }
    ];

    this.colors = [
      { label: 'White', value: 'White' },
      { label: 'Green', value: 'Green' },
      { label: 'Silver', value: 'Silver' },
      { label: 'Black', value: 'Black' },
      { label: 'Red', value: 'Red' },
      { label: 'Maroon', value: 'Maroon' },
      { label: 'Brown', value: 'Brown' },
      { label: 'Orange', value: 'Orange' },
      { label: 'Blue', value: 'Blue' }
    ];

  }
}
