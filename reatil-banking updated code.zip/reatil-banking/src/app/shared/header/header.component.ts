import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { NotificationService } from 'src/app/service/notification-service';

import { Service } from 'src/app/service/service';
import { Cart } from 'src/app/model/model';
import { UrlConfig } from 'src/app/service/url-config';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {
  toggleFlag = false;
  constructor(
    ) {

    }


  ngOnInit() {

  }
  public toggle(): void {
    this.toggleFlag = !this.toggleFlag;
  }
  ngOnDestroy() {
   /* unsubscribe to ensure no memory leaks */

  }

}
