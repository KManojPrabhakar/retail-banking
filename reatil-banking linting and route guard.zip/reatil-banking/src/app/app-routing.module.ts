import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './service/auth-guard';
import { RouteGuard } from './service/router-guard';
import { DashboardComponent } from './module/dashboard/pages/dashboard/dashboard.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path: 'member',
    loadChildren: () => import(`./module/member/member.module`).then(m => m.MemberModule),
    canActivate: [RouteGuard]

  },
  {
    path: 'dashboard',
    loadChildren: () => import('src/app/module/dashboard/dashboard.module').then(m => m.DashboardModule)
  },
  {
    path: 'fundtransfer',
    loadChildren: () => import('src/app/module/fundtransfer/fundtransfer.module').then(m => m.FundtransferModule),
    canActivate: [RouteGuard]
  },
  { path: '**', component: DashboardComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
