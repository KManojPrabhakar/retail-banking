export interface Product {
  id: number;
  imageurl: string;
  categoryName: string;
  itemname: string;
  price: string;
  detail: [
    {
      size: string;
      quantity: number;
    }
  ];
}
export interface Cart {
  id: number;
  imageurl: string;
  categoryName: string;
  itemname: string;
  price: number;
  size: string;
  quantity: number;

}
export interface ProductDetail {
  product: [
    {  id: number;
      imageurl: string;
      categoryName: string;
      itemname: string;
      price: string;
      detail: [
        {
          size: string;
          quantity: number;
        }
      ]; }
  ];
}
