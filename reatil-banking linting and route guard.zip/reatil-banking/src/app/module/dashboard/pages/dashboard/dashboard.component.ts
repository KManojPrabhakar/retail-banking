import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app/service/service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private service: Service) { }

  ngOnInit(): void {
    this.getMockData();
  }

  getMockData() {
    const url ='http://localhost:3000/cart';
    this.service.getList(url).subscribe(
      data => {
        console.log('mock data ', data);
      }
    );
  }

}
