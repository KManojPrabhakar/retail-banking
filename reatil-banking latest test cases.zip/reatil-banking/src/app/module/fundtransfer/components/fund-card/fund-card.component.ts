import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-fund-card',
  templateUrl: './fund-card.component.html',
  styleUrls: ['./fund-card.component.css']
})
export class FundCardComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  navigateToAddBeneficiaryAccount() {
    console.log('navigateToAddBeneficiaryAccount');
    const url = 'fundtransfer/beneficiary';
    this.router.navigate([url]);
  }

  navigateToPaymentPage() {
    console.log('navigateToAddBeneficiaryAccount');
    const url = 'fundtransfer/payee';
    this.router.navigate([url]);
  }

}
