import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FundComponent } from './pages/fund/fund.component';
import { AddBeneficiaryComponent } from './pages/add-beneficiary/add-beneficiary.component';


const routes: Routes = [
  {
    path: '', 
    component: FundComponent
  },
  {
    path: 'beneficiary',
    component: AddBeneficiaryComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FundtransferRoutingModule { }
