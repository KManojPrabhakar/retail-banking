import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddBeneficiaryComponent } from './add-beneficiary.component';
import { RouterTestingModule } from '@angular/router/testing';
import { DebugElement } from '@angular/core';
import { BrowserModule, By} from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HelperService } from 'src/app/service/helper.service';
import { Router } from '@angular/router';

describe('AddBeneficiaryComponent', () => {
  let component: AddBeneficiaryComponent;
  let fixture: ComponentFixture<AddBeneficiaryComponent>;
  let de: DebugElement;
  let e1: HTMLElement;
  let helperService: HelperService;
  
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddBeneficiaryComponent ],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule
      ]
    
    })
    .compileComponents().then( () => {
      fixture = TestBed.createComponent(AddBeneficiaryComponent);
      component = fixture.componentInstance;  // AddBeneficiaryComponent ts test file
      de = fixture.debugElement.query(By.css('form'));
      e1 = de.nativeElement;
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddBeneficiaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('beneficiaryForm  should be invalid', () => {
    component.beneficiaryForm.controls['accountNo'].setValue('');
    component.beneficiaryForm.controls['reEnterAccountNo'].setValue('');
    component.beneficiaryForm.controls['nickName'].setValue('');
    component.beneficiaryForm.controls['emailId'].setValue('');
    expect(component.beneficiaryForm.valid).toBeFalsy();


  })

  it('beneficiaryForm  should be valid', () => {
    component.beneficiaryForm.controls['accountNo'].setValue(1234);
    component.beneficiaryForm.controls['reEnterAccountNo'].setValue(1234567890);
    component.beneficiaryForm.controls['nickName'].setValue('manoj');
    component.beneficiaryForm.controls['emailId'].setValue('manoj@gmail.com');
    expect(component.beneficiaryForm.valid).toBeTruthy();

  });

  it('beneficiary component  navigate to history back', () => {
    helperService = new HelperService();
    spyOn(window.history, 'back');
    expect(helperService.navigateToHistoryBack()).toEqual(window.history.back());
  });

  it('#number only method ', () => {
    // helperService = new HelperService();
    // const bannerElement: HTMLElement = fixture.nativeElement;
    // const input = bannerElement.querySelector('input');
    // console.log('number only', input);
    // const event = new KeyboardEvent('keyPress');
    // // expect(helperService.numberOnly(input)).toHaveBeenCalled();
    // expect(helperService.numberOnly(  event    )).toBe(null);

    const hostElement = fixture.nativeElement;
    const nameInput: HTMLInputElement = hostElement.querySelector('input');
    const event = new KeyboardEvent("keypress",{
      "key": "Enter"
  });
    nameInput.dispatchEvent(event);
    fixture.detectChanges();
    expect(component.numberOnly(event)).toBe(helperService.numberOnly(event));


  });

});
