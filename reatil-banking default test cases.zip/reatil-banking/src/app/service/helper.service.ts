import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class HelperService {

  accountBalance = 10000;

  constructor(private router: Router) { }

  navigateToHistoryBack() {
    window.history.back();
  }

  addBeneficiaryDetails(beneficiaryData) {
    sessionStorage.setItem('beneficiaryData', JSON.stringify(beneficiaryData));

  }

  getBeneficiaryDetails() {
    return sessionStorage.getItem('beneficiaryData');
  }

  storeTranscationDetails(transactionData) {
    sessionStorage.setItem('transactionData', JSON.stringify(transactionData));

  }
  getTranscationDetails() {
    return sessionStorage.getItem('transactionData');
  }

  getAccountBalance() {
    return this.accountBalance;
  }

  getCurrentBalance() {
    let transactionDetails;
    let availableBalance = this.getAccountBalance();
    transactionDetails = this.getTranscationDetails();

    if(transactionDetails && transactionDetails.length) {
      transactionDetails = JSON.parse(transactionDetails);
    } else {
      transactionDetails = [];
    }
    transactionDetails.map((item) => {
      availableBalance-=item.withdraw;
    })
    return availableBalance;


  }

  numberOnly(event): boolean {
    if (event && event.target) {
      const value = event.target.value;
      const charCode = (event.which) ? event.which : event.keyCode;
      if (charCode === 46 && value.split('.').length > 1) {
        return false;
      }
      if (charCode === 46 && (value.split('.').length <= 1)) {
        return true;
      }
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
      }
      if (value && Number(value) === 0) {
        return false;
      }
      return true;
    }
  }
}
